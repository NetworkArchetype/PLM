import cirq
print('Hello from Cirq in image (repro):', cirq.__version__)
